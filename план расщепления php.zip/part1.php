<?php
header ("Content-Type: text/html; charset=utf-8");

echo "<button id='btn'>".$_POST['text']."</button>";
?>
