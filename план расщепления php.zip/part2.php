<?php
header ("Content-Type: text/html; charset=utf-8");

echo "[1,2,3]";
?>
